# KYNORA Android starter

This is an early native Android starter project for KYNORA.

## Build
The repository workflow uses GitHub Actions to build a debug APK. Upload this ZIP to the repository root after creating `.github/workflows/android.yml`.

## Current scope
- Kotlin + Jetpack Compose Android app
- Home, Create, Explore and Collection screens
- A deterministic offline idea-template generator (not a neural LLM)
- Local in-memory saved sparks for this starter
- Android share sheet

## Not yet included
A real on-device neural AI model, photo/voice generation, cloud sync, accounts, community moderation, production persistence, privacy policy, release signing, and Play Store publication. These require later implementation and testing.
