package com.kynora.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Panel2 = Color(0xFF1C2340)
private val Purple = Color(0xFF9A7BFF)
private val Blue = Color(0xFF5AC8FA)
private val White = Color(0xFFF6F5FF)
private val Soft = Color(0xFF9BA4BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KynoraPremiumApp() }
    }
}

@Composable
fun KynoraPremiumApp() {
    var tab by remember { mutableIntStateOf(0) }
    var mode by remember { mutableStateOf("Auto") }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(listOf<String>()) }
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Blue, background = Bg, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101525), contentColor = White) {
                    val labels = listOf("Home", "Create", "Explore", "Saved")
                    val icons = listOf(Icons.Default.Home, Icons.Default.AutoAwesome, Icons.Default.Explore, Icons.Default.Bookmark)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple, selectedTextColor = White,
                                indicatorColor = Panel2, unselectedIconColor = Soft,
                                unselectedTextColor = Soft
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                TopBar()
                when (tab) {
                    0 -> HomeScreen(
                        onCreate = { tab = 1 },
                        onExplore = { tab = 2 },
                        mode = mode,
                        onMode = { mode = it }
                    )
                    1 -> CreateScreen(
                        prompt = prompt, onPrompt = { prompt = it },
                        mode = mode, onMode = { mode = it },
                        answer = answer,
                        onGenerate = {
                            val idea = prompt.trim()
                            answer = if (idea.isBlank()) "Add your idea above to get started."
                            else "Your creative brief\\n\\nConcept: $idea\\n\\nDirection: Give it a distinctive identity, a clear emotional hook, and one unexpected detail.\\n\\nFirst step: Write a one-sentence version of the idea, then choose the strongest detail to develop."
                        },
                        onSave = { if (answer.isNotBlank()) saved = saved + answer },
                        onShare = {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, answer)
                            }
                            context.startActivity(Intent.createChooser(share, "Share your idea"))
                        }
                    )
                    2 -> ExploreScreen(onPick = { prompt = it; tab = 1 })
                    else -> SavedScreen(saved = saved)
                }
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Purple, Blue))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("KYNORA", color = White, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 2.sp)
            Text("YOUR CREATIVE UNIVERSE", color = Soft, fontSize = 9.sp, letterSpacing = 1.6.sp)
        }
        Box(Modifier.size(38.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Soft)
        }
    }
}

@Composable
private fun HomeScreen(onCreate: () -> Unit, onExplore: () -> Unit, mode: String, onMode: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("THINK IT. CREATE IT.", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        Text("Your ideas,\nwithout limits.", color = White, fontSize = 34.sp, lineHeight = 39.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("A creative space powered by AI — ready whenever inspiration strikes.", color = Soft, fontSize = 14.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(22.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF34245E), Color(0xFF172C4A), Color(0xFF171B31))))
                .padding(20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFD8CBFF))
                    Spacer(Modifier.width(8.dp))
                    Text("KYNORA STUDIO", color = Color(0xFFD8CBFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
                Spacer(Modifier.height(13.dp))
                Text("Make something\nremarkable today.", color = White, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Start with a thought. Leave with a possibility.", color = Color(0xFFD0D4E5), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onCreate, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Bg)) {
                    Text("Start creating", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
        Spacer(Modifier.height(23.dp))
        SectionTitle("AI MODE", "Choose how KYNORA responds")
        Spacer(Modifier.height(11.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Auto", "Offline", "Online").forEach { item ->
                val selected = mode == item
                Surface(
                    onClick = { onMode(item) },
                    color = if (selected) Color(0xFF302653) else Panel,
                    shape = RoundedCornerShape(13.dp),
                    border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, Purple) else null,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(when (item) { "Offline" -> Icons.Default.PhoneAndroid; "Online" -> Icons.Default.Cloud; else -> Icons.Default.SmartToy }, null, tint = if (selected) Purple else Soft)
                        Spacer(Modifier.height(5.dp))
                        Text(item, color = if (selected) White else Soft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(23.dp))
        SectionTitle("QUICK ACCESS", "Explore your creative tools")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickCard("Create", "Ideas & writing", Icons.Default.Edit, Modifier.weight(1f), onCreate)
            QuickCard("Explore", "Find inspiration", Icons.Default.Explore, Modifier.weight(1f), onExplore)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun CreateScreen(
    prompt: String, onPrompt: (String) -> Unit, mode: String, onMode: (String) -> Unit,
    answer: String, onGenerate: () -> Unit, onSave: () -> Unit, onShare: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("CREATE STUDIO", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text("What will you\ncreate today?", color = White, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Describe your idea. KYNORA will help shape your next step.", color = Soft, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Text("AI MODE", color = Soft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Auto", "Offline", "Online").forEach {
                FilterChip(selected = mode == it, onClick = { onMode(it) }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("I want to create a short film about...", color = Soft) },
            minLines = 5, shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF303852),
                focusedTextColor = White, unfocusedTextColor = White, cursorColor = Purple
            )
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Generate idea", fontWeight = FontWeight.Bold)
        }
        if (answer.isNotBlank()) {
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(17.dp)) {
                    Text("YOUR CREATIVE BRIEF", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(answer, color = White, fontSize = 14.sp, lineHeight = 22.sp)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        TextButton(onClick = onSave) { Icon(Icons.Default.BookmarkAdd, null); Text(" Save") }
                        TextButton(onClick = onShare) { Icon(Icons.Default.Share, null); Text(" Share") }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ExploreScreen(onPick: (String) -> Unit) {
    val prompts = listOf(
        "A short film with a surprising ending",
        "A fresh streetwear brand for young creators",
        "A useful Android app that solves an everyday problem",
        "A funny 30-second food advertisement",
        "A futuristic room with a calm, minimal mood"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("DISCOVER", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text("Find your next spark.", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Pick a starting point and make it your own.", color = Soft)
        Spacer(Modifier.height(18.dp))
        prompts.forEachIndexed { i, p ->
            Card(
                onClick = { onPick(p) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(17.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                        Text("0${i + 1}", color = Purple, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(p, color = White, modifier = Modifier.weight(1f), fontSize = 14.sp)
                    Icon(Icons.Default.ArrowForward, null, tint = Soft)
                }
            }
        }
    }
}

@Composable
private fun SavedScreen(saved: List<String>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("YOUR LIBRARY", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Text("Saved creations", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (saved.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Bookmarks, null, tint = Soft, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Your ideas will live here.", color = White, fontWeight = FontWeight.SemiBold)
                    Text("Save a creation from Create Studio.", color = Soft, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn { items(saved) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text(item, color = White, modifier = Modifier.padding(15.dp), lineHeight = 21.sp)
                }
            } }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text(subtitle, color = Soft, fontSize = 11.sp)
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Purple)
            Spacer(Modifier.height(13.dp))
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = Soft, fontSize = 11.sp)
        }
    }
}
