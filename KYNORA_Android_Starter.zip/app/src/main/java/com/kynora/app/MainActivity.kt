package com.kynora.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101426)
private val Violet = Color(0xFF8067FF)
private val Muted = Color(0xFF9BA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KynoraApp() }
    }
}

@Composable
fun KynoraApp() {
    var tab by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Your next idea starts here.") }
    var saved by remember { mutableStateOf(listOf<String>()) }
    val context = LocalContext.current
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Color(0xFF1A2035))) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF171D30)) {
                    listOf("Home", "Create", "Explore", "Collection").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(listOf(Icons.Default.Home, Icons.Default.AutoAwesome, Icons.Default.Explore, Icons.Default.Bookmark)[i], null) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                Text("KYNORA", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Text("CREATE BEYOND IMAGINATION", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(24.dp))
                when (tab) {
                    0 -> {
                        Text("Your creative universe", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Turn a small thought into your next big idea.", color = Muted)
                        Spacer(Modifier.height(20.dp))
                        FeatureCard("Offline Spark", "Create ideas even without internet", "Start creating") { tab = 1 }
                        FeatureCard("Explore", "Find a spark to get you started", "Explore ideas") { tab = 2 }
                    }
                    1 -> {
                        Text("Create a Spark", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Describe what you want to create.", color = Muted)
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Your idea") }, minLines = 3)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            val seed = prompt.trim().ifBlank { "something amazing" }
                            result = "Try this: Create a fresh concept around $seed. Give it a bold title, one surprising twist, and a simple first step."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Generate offline idea") }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202943)), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("YOUR SPARK", color = Violet, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(result, color = Color.White)
                                TextButton(onClick = { saved = saved + result }) { Text("Save to collection") }
                                TextButton(onClick = {
                                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, result) }
                                    context.startActivity(Intent.createChooser(send, "Share your spark"))
                                }) { Text("Share spark") }
                            }
                        }
                    }
                    2 -> {
                        Text("Explore ideas", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        val ideas = listOf("A short film with a surprising ending", "A brand for tomorrow's creators", "A useful app for everyday life", "A futuristic room design")
                        LazyColumn { items(ideas) { idea -> FeatureCard(idea, "Tap to use this as your starting point", "Use idea") { prompt = idea; tab = 1 } } }
                    }
                    else -> {
                        Text("Your collection", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        if (saved.isEmpty()) Text("Your saved sparks will appear here.", color = Muted)
                        LazyColumn { items(saved) { Text(it, color = Color.White, modifier = Modifier.padding(vertical = 10.dp)) } }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, action: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF202943)),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Muted)
            TextButton(onClick = onClick) { Text(action) }
        }
    }
}
