# KYNORA Premium UI Starter

A native Android Jetpack Compose UI refresh for KYNORA, with a premium dark visual system, home dashboard, AI mode selector UI, Create Studio, Explore and Saved screens.

Important: The Auto / Offline / Online selector is currently a UI control only. It does not yet connect to a real AI model or online backend. The Create action still produces a local demo brief. Real LiteRT-LM offline inference and a secure online backend must be implemented and tested separately.
